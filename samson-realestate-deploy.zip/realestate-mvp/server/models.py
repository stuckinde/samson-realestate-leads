from typing import Optional, List
from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime

class LeadBase(SQLModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    role: str = "seller"  # 'seller' or 'buyer'
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    beds: Optional[int] = None
    baths: Optional[float] = None
    sqft: Optional[int] = None
    price_min: Optional[int] = None
    price_max: Optional[int] = None
    timeline: Optional[str] = None  # '0-3', '3-6', '6-12', '12+' months
    source: Optional[str] = "direct"
    tags: Optional[str] = None  # comma-separated
    score: int = 0
    consent_sms: bool = False
    consent_email: bool = False
    stage: str = "New"  # New → Contacted → Qualified → Appointment → Agreement → Closed/Lost

class Lead(LeadBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class Event(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    lead_id: int = Field(foreign_key="lead.id")
    type: str  # 'page_view', 'form_submit', 'sms_sent', 'email_sent', 'valuation'
    metadata_json: Optional[str] = None
    occurred_at: datetime = Field(default_factory=datetime.utcnow)
