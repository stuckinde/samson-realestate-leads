from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from sqlmodel import select
from datetime import datetime
import json

from .database import init_db, get_session
from .models import Lead, Event
from .valuation import estimate_value

app = FastAPI(title="Real Estate Lead-Gen MVP", version="0.1.0")

# Serve the static front-end
from pathlib import Path
WEB_DIR = str((Path(__file__).resolve().parents[1] / "web"))
app.mount("/", StaticFiles(directory=WEB_DIR, html=True), name="static")

@app.on_event("startup")
def on_startup():
    init_db()

def compute_score(lead: Lead) -> int:
    score = 0
    if lead.phone: score += 15
    if lead.email: score += 10
    if lead.price_min or lead.price_max: score += 10
    if lead.timeline in ("0-3","3-6"): score += 15
    if lead.role == "seller" and lead.address: score += 20
    if lead.consent_sms: score += 10
    if lead.consent_email: score += 5
    # stage bonus
    stage_bonus = {"New":0,"Contacted":5,"Qualified":10,"Appointment":20,"Agreement":30,"Closed/Lost":0}
    score += stage_bonus.get(lead.stage,0)
    return int(score)

@app.post("/api/valuation")
async def do_valuation(payload: dict):
    zip_code = payload.get("zip_code")
    beds = payload.get("beds")
    baths = payload.get("baths")
    sqft = payload.get("sqft")
    result = estimate_value(zip_code, beds, baths, sqft)
    return {"ok": True, "valuation": result}

@app.post("/api/leads")
async def create_lead(payload: dict):
    with get_session() as session:
        lead = Lead(**payload)
        lead.updated_at = datetime.utcnow()
        lead.score = compute_score(lead)
        session.add(lead)
        session.commit()
        session.refresh(lead)
        ev = Event(lead_id=lead.id, type="form_submit", metadata_json=json.dumps(payload))
        session.add(ev)
        session.commit()
        return {"ok": True, "lead": lead.dict()}

@app.get("/api/leads")
async def list_leads(q: str | None = None, role: str | None = None, stage: str | None = None):
    with get_session() as session:
        stmt = select(Lead)
        leads = session.exec(stmt).all()
        def match(ld: Lead) -> bool:
            if role and ld.role != role: return False
            if stage and ld.stage != stage: return False
            if q:
                t = (q or "").lower()
                blob = " ".join([str(getattr(ld, k, "") or "") for k in ("first_name","last_name","email","phone","address","city","state","zip_code","tags","role","stage")]).lower()
                return t in blob
            return True
        results = [ld.dict() for ld in leads if match(ld)]
        # sort by score desc, then created_at desc
        results.sort(key=lambda x: (x.get("score",0), x.get("created_at","")), reverse=True)
        return {"ok": True, "items": results}

@app.patch("/api/leads/{lead_id}")
async def update_lead(lead_id: int, payload: dict):
    with get_session() as session:
        lead = session.get(Lead, lead_id)
        if not lead:
            raise HTTPException(status_code=404, detail="Lead not found")
        for k,v in payload.items():
            if hasattr(lead, k):
                setattr(lead, k, v)
        lead.updated_at = datetime.utcnow()
        lead.score = compute_score(lead)
        session.add(lead)
        session.commit()
        session.refresh(lead)
        return {"ok": True, "lead": lead.dict()}

@app.post("/api/events/{lead_id}")
async def add_event(lead_id: int, payload: dict):
    with get_session() as session:
        lead = session.get(Lead, lead_id)
        if not lead:
            raise HTTPException(status_code=404, detail="Lead not found")
        ev = Event(lead_id=lead.id, type=payload.get("type","custom"), metadata_json=json.dumps(payload.get("meta",{})))
        session.add(ev)
        session.commit()
        return {"ok": True}

@app.get("/api/health")
async def health():
    return {"ok": True, "service": "lead-gen-mvp", "version": "0.1.0"}
