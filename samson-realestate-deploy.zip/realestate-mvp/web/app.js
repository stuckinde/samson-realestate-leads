// Tab switching
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(p=>p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'dashboard') loadLeads();
  });
});

// Helper
async function postJSON(url, data){
  const res = await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  if(!res.ok) throw new Error('Request failed');
  return await res.json();
}
async function patchJSON(url, data){
  const res = await fetch(url,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  if(!res.ok) throw new Error('Request failed');
  return await res.json();
}

// SELL: valuation
const valForm = document.getElementById('valuation-form');
valForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(valForm);
  const payload = Object.fromEntries(fd.entries());
  const tagbits = [];
  if (payload.preapproved) tagbits.push("preapproved:"+payload.preapproved);
  if (payload.neighborhoods) tagbits.push("neighborhoods:"+payload.neighborhoods);
  payload.tags = [payload.tags || '', tagbits.join('|')].filter(Boolean).join('|');
  // attach seller extras into tags
  const tagbits = [];
  if (payload.seller_reason) tagbits.push("reason:"+payload.seller_reason);
  if (payload.sell_before_buy) tagbits.push("sellBeforeBuy:"+payload.sell_before_buy);
  payload.tags = [payload.tags || '', tagbits.join('|')].filter(Boolean).join('|');
  payload.beds = payload.beds ? Number(payload.beds) : null;
  payload.baths = payload.baths ? Number(payload.baths) : null;
  payload.sqft = payload.sqft ? Number(payload.sqft) : null;

  const out = document.getElementById('valuation-result');
  out.classList.add('hidden');
  out.innerHTML = '';

  try {
    const resp = await postJSON('/api/valuation', payload);
    const v = resp.valuation;
    out.innerHTML = `
      <h3>Estimated Value</h3>
      <p style="font-size:22px;margin:4px 0;"><strong>$${v.estimate.toLocaleString()}</strong> <span class="badge">range: $${v.low.toLocaleString()} – $${v.high.toLocaleString()}</span></p>
      <p class="hint">Using $${v.ppsf_used}/sqft × ${v.sqft_used} sqft (adj factor ${v.adjustment}). This is a quick estimate for demo only.</p>
    `;
    out.classList.remove('hidden');
  } catch(err){
    out.innerHTML = '<p style="color:#ffb4b4">Could not compute estimate.</p>';
    out.classList.remove('hidden');
  }
});

// SELL: lead submit
const sellerForm = document.getElementById('seller-lead-form');
sellerForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(sellerForm);
  const payload = Object.fromEntries(fd.entries());
  const tagbits = [];
  if (payload.preapproved) tagbits.push("preapproved:"+payload.preapproved);
  if (payload.neighborhoods) tagbits.push("neighborhoods:"+payload.neighborhoods);
  payload.tags = [payload.tags || '', tagbits.join('|')].filter(Boolean).join('|');
  // attach seller extras into tags
  const tagbits = [];
  if (payload.seller_reason) tagbits.push("reason:"+payload.seller_reason);
  if (payload.sell_before_buy) tagbits.push("sellBeforeBuy:"+payload.sell_before_buy);
  payload.tags = [payload.tags || '', tagbits.join('|')].filter(Boolean).join('|');
  payload.consent_sms = !!fd.get('consent_sms');
  payload.consent_email = !!fd.get('consent_email');

  // also copy address/zip/beds/baths/sqft from valuation form if available
  const vfd = new FormData(document.getElementById('valuation-form'));
  ['address','zip_code','beds','baths','sqft'].forEach(k=>{
    const v = vfd.get(k);
    if (v && !payload[k]) payload[k] = v;
  });

  try {
    const resp = await postJSON('/api/leads', payload);
    alert('Thanks! Your request was received. We will contact you shortly.');
    sellerForm.reset();
  } catch(err){
    alert('Could not submit lead.');
  }
});

// BUY: lead submit
const buyerForm = document.getElementById('buyer-lead-form');
buyerForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(buyerForm);
  const payload = Object.fromEntries(fd.entries());
  const tagbits = [];
  if (payload.preapproved) tagbits.push("preapproved:"+payload.preapproved);
  if (payload.neighborhoods) tagbits.push("neighborhoods:"+payload.neighborhoods);
  payload.tags = [payload.tags || '', tagbits.join('|')].filter(Boolean).join('|');
  // attach seller extras into tags
  const tagbits = [];
  if (payload.seller_reason) tagbits.push("reason:"+payload.seller_reason);
  if (payload.sell_before_buy) tagbits.push("sellBeforeBuy:"+payload.sell_before_buy);
  payload.tags = [payload.tags || '', tagbits.join('|')].filter(Boolean).join('|');
  payload.consent_sms = !!fd.get('consent_sms');
  payload.consent_email = !!fd.get('consent_email');
  ['beds','baths','price_min','price_max'].forEach(k=>{
    if (payload[k]) payload[k] = Number(payload[k]);
  });
  try {
    const resp = await postJSON('/api/leads', payload);
    alert('Saved! We will send property alerts (mocked in this demo).');
    buyerForm.reset();
  } catch(err){
    alert('Could not submit lead.');
  }
});

// DASHBOARD
const qEl = document.getElementById('filter-q');
const roleEl = document.getElementById('filter-role');
const stageEl = document.getElementById('filter-stage');
document.getElementById('btn-refresh').addEventListener('click', loadLeads);

async function loadLeads(){
  const params = new URLSearchParams();
  if(qEl.value) params.set('q', qEl.value.trim());
  if(roleEl.value) params.set('role', roleEl.value);
  if(stageEl.value) params.set('stage', stageEl.value);

  const res = await fetch('/api/leads?'+params.toString());
  const data = await res.json();
  const tbl = document.getElementById('leads-table');
  if(!data.ok){ tbl.innerHTML = '<p>Failed to load leads.</p>'; return; }

  const rows = data.items.map(ld=>{
    const name = [ld.first_name||'', ld.last_name||''].join(' ').trim() || '(no name)';
    const contact = [ld.email||'', ld.phone||''].filter(Boolean).join(' · ') || '—';
    const addr = [ld.address||'', ld.zip_code||''].filter(Boolean).join(', ');
    return `
      <tr>
        <td><span class="badge">${ld.role}</span></td>
        <td><strong>${name}</strong><br><span class="hint">${contact}</span></td>
        <td>${addr || '—'}</td>
        <td>${ld.timeline || '—'}</td>
        <td>${ld.score}</td>
        <td>
          <select data-lead="${ld.id}" class="stage-picker">
            ${['New','Contacted','Qualified','Appointment','Agreement','Closed/Lost'].map(s=>`<option ${s===ld.stage?'selected':''}>${s}</option>`).join('')}
          </select>
        </td>
      </tr>
    `;
  }).join('');

  tbl.innerHTML = `
    <table class="table">
      <thead>
        <tr>
          <th>Role</th><th>Lead</th><th>Location</th><th>Timeline</th><th>Score</th><th>Stage</th>
        </tr>
      </thead>
      <tbody>${rows || '<tr><td colspan="6">No leads yet.</td></tr>'}</tbody>
    </table>
  `;

  document.querySelectorAll('.stage-picker').forEach(sel=>{
    sel.addEventListener('change', async (e)=>{
      const id = e.target.getAttribute('data-lead');
      const stage = e.target.value;
      await patchJSON(`/api/leads/${id}`, {stage});
      await loadLeads();
    });
  });
}

// kick off
if (document.querySelector('.tab.active')?.dataset.tab === 'dashboard') loadLeads();
